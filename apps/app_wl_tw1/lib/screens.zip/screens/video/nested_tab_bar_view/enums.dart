enum LikeButtonType { favorite, bookmark }

enum VideoFilterType { actor, category, tag }
