// ChannelStyle2 is a stateless widget, return Text 'STYLE 2
import 'package:flutter/material.dart';

class ChannelStyleNotFound extends StatelessWidget {
  const ChannelStyleNotFound({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('STYLE Not Found'),
    );
  }
}
